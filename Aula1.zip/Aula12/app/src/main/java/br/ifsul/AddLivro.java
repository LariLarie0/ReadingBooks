package br.ifsul;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddLivro extends AppCompatActivity {

    Button botao2;
     EditText nome;
     EditText pg;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_livro);

        botao2 = findViewById(R.id.Add2);

        nome = findViewById(R.id.Nome);
        pg = findViewById(R.id.N_Pg);


        botao2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String livro = nome.getText().toString();
                int pgs = Integer.parseInt(pg.getText().toString());

                Intent a = new Intent();
                a.putExtra("livro", livro);
                a.putExtra("pgs", pgs);
                setResult(RESULT_OK, a);
                finish();
    }
        });
    }
}